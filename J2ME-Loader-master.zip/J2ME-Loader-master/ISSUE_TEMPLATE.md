**Emulator version:**


**Game version:**


**Game resolution:**
``(For example, 240x320 or 640x360)``

**Device:**
``(For example, Samsung Galaxy S7)``

**Android version:**

**Description of the issue:**
``(What's the problem? - Screenshots showing the issue if applicable)``

