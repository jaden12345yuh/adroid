package javax.microedition.media;

interface TimeBase {
	long getTime();
}
